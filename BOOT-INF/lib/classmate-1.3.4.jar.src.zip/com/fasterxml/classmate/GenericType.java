package com.fasterxml.classmate;

import java.io.Serializable;
import java.lang.reflect.Type;

public abstract class GenericType<T>
  implements Serializable, Type
{}


/* Location:              C:\Users\ikatwal\Downloads\bullet-zone-server-2.0.jar!\BOOT-INF\lib\classmate-1.3.4.jar!\com\fasterxml\classmate\GenericType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */