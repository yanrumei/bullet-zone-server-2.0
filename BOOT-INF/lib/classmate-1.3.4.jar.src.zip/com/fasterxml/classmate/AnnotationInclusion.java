package com.fasterxml.classmate;

public enum AnnotationInclusion
{
  DONT_INCLUDE,  INCLUDE_BUT_DONT_INHERIT,  INCLUDE_AND_INHERIT_IF_INHERITED,  INCLUDE_AND_INHERIT;
  
  private AnnotationInclusion() {}
}


/* Location:              C:\Users\ikatwal\Downloads\bullet-zone-server-2.0.jar!\BOOT-INF\lib\classmate-1.3.4.jar!\com\fasterxml\classmate\AnnotationInclusion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */